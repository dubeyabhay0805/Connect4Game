package com.example.connect4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class TwoPlayerActivity extends AppCompatActivity {

    private static final int ROWS = 6;
    private static final int COLS = 7;
    private int[][] board = new int[ROWS][COLS]; // 0 = empty, 1 = Player 1, 2 = Player 2
    private boolean playerOneTurn = true;
    private boolean gameOver = false;

    private GridLayout gridLayout;
    private TextView statusText;
    private Button restartButton, exitButton;
    private ImageView[][] cells = new ImageView[ROWS][COLS];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_player);

        gridLayout = findViewById(R.id.gridLayout);
        statusText = findViewById(R.id.statusText);
        restartButton = findViewById(R.id.restartButton);
        exitButton = findViewById(R.id.exitButton);

        initializeBoard();

        restartButton.setOnClickListener(v -> resetGame());
        exitButton.setOnClickListener(v -> finish());
    }

    private void initializeBoard() {
        gridLayout.removeAllViews();
        gameOver = false;
        playerOneTurn = true;
        statusText.setText("Your Turn!");

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                board[row][col] = 0;
                cells[row][col] = new ImageView(this);
                cells[row][col].setImageResource(R.drawable.empty);
                cells[row][col].setPadding(5, 5, 5, 5);
                int finalCol = col;
                cells[row][col].setOnClickListener(v -> {
                    if (!gameOver) {
                        dropPiece(finalCol);
                    }
                });

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = 130;
                params.height = 130;
                params.setMargins(4, 4, 4, 4);
                cells[row][col].setLayoutParams(params);

                gridLayout.addView(cells[row][col]);
            }
        }
    }

    private void dropPiece(int col) {
        if (gameOver) return;

        int row = getAvailableRow(col);
        if (row == -1) return;

        int player = playerOneTurn ? 1 : 2;
        board[row][col] = player;
        cells[row][col].setImageResource(playerOneTurn ? R.drawable.red_piece : R.drawable.yellow_piece);

        String winType = checkWin(row, col, player);
        if (!winType.equals("none")) {
            statusText.setText("Player " + (playerOneTurn ? "1" : "2") + " Wins!");
            gameOver = true;
            return;
        }

        playerOneTurn = !playerOneTurn;
        statusText.setText("Player " + (playerOneTurn ? "1" : "2") + "'s Turn!");
    }

    private int getAvailableRow(int col) {
        for (int row = ROWS - 1; row >= 0; row--) {
            if (board[row][col] == 0) return row;
        }
        return -1;
    }

    private String checkWin(int row, int col, int player) {
        if (checkDirection(row, col, 0, 1, player)) return "Horizontally";
        if (checkDirection(row, col, 1, 0, player)) return "Vertically";
        if (checkDirection(row, col, 1, 1, player)) return "Diagonally ↘";
        if (checkDirection(row, col, 1, -1, player)) return "Diagonally ↙";
        return "none";
    }

    private boolean checkDirection(int row, int col, int rowDir, int colDir, int player) {
        int count = 1;
        count += countConsecutive(row, col, rowDir, colDir, player);
        count += countConsecutive(row, col, -rowDir, -colDir, player);
        return count >= 4;
    }

    private int countConsecutive(int row, int col, int rowDir, int colDir, int player) {
        int count = 0;
        for (int i = 1; i < 4; i++) {
            int newRow = row + i * rowDir;
            int newCol = col + i * colDir;
            if (newRow >= 0 && newRow < ROWS && newCol >= 0 && newCol < COLS && board[newRow][newCol] == player) {
                count++;
            } else {
                break;
            }
        }
        return count;
    }

    private void resetGame() {
        initializeBoard();
    }
}
