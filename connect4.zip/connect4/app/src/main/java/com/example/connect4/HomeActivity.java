package com.example.connect4;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Button playAIButton = findViewById(R.id.playButton);
        Button playTwoPlayerButton = findViewById(R.id.playTwoPlayerButton);
        Button howToPlayButton = findViewById(R.id.howToPlayButton);

        playAIButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, MainActivity.class);
            startActivity(intent);
        });

        playTwoPlayerButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, TwoPlayerActivity.class);
            startActivity(intent);
        });

        howToPlayButton.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, HowToPlayActivity.class);
            startActivity(intent);
        });
    }
}
