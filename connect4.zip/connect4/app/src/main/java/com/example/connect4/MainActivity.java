package com.example.connect4;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final int ROWS = 6;
    private static final int COLS = 7;
    private int[][] board = new int[ROWS][COLS]; // 0 = empty, 1 = Player 1, 2 = Player 2 (or AI)
    private boolean playerTurn = true;
    private boolean gameOver = false;
    private boolean isTwoPlayerMode = false;

    private GridLayout gridLayout;
    private TextView statusText;
    private Button restartButton, exitButton;
    private ImageView[][] cells = new ImageView[ROWS][COLS];
    private Handler handler = new Handler();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridLayout = findViewById(R.id.gridLayout);
        statusText = findViewById(R.id.statusText);
        restartButton = findViewById(R.id.restartButton);
        exitButton = findViewById(R.id.exitButton);

        isTwoPlayerMode = getIntent().getBooleanExtra("TWO_PLAYER_MODE", false);

        initializeBoard();

        restartButton.setOnClickListener(v -> resetGame());
        exitButton.setOnClickListener(v -> finish());
    }

    private void initializeBoard() {
        gridLayout.removeAllViews();
        gameOver = false;
        playerTurn = true;
        statusText.setText("Player 1's Turn");

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                board[row][col] = 0;
                cells[row][col] = new ImageView(this);
                cells[row][col].setImageResource(R.drawable.empty);
                cells[row][col].setPadding(8, 8, 8, 8);
                int finalCol = col;
                cells[row][col].setOnClickListener(v -> {
                    if (!gameOver) dropPiece(finalCol);
                });

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = 140;
                params.height = 140;
                params.setMargins(6, 6, 6, 6);
                cells[row][col].setLayoutParams(params);

                gridLayout.addView(cells[row][col]);
            }
        }
    }

    private void dropPiece(int col) {
        if (gameOver) return;

        int row = getAvailableRow(col);
        if (row == -1) return;

        int currentPlayer = playerTurn ? 1 : 2;
        board[row][col] = currentPlayer;
        cells[row][col].setImageResource(playerTurn ? R.drawable.red_piece : R.drawable.yellow_piece);

        String winType = checkWin(row, col, currentPlayer);
        if (!winType.equals("none")) {
            statusText.setText("Player " + currentPlayer + " Won " + winType + "!");
            gameOver = true;
            return;
        }

        if (isTwoPlayerMode) {
            playerTurn = !playerTurn;
            statusText.setText(playerTurn ? "Player 1's Turn" : "Player 2's Turn");
        } else {
            playerTurn = false;
            statusText.setText("AI is thinking...");
            handler.postDelayed(this::aiMove, 1500);
        }
    }

    private void aiMove() {
        if (gameOver) return;

        int bestMove = getBestMove();
        if (!isValidMove(bestMove)) bestMove = getRandomMove();

        int row = getAvailableRow(bestMove);
        if (row == -1) return;

        board[row][bestMove] = 2;
        cells[row][bestMove].setImageResource(R.drawable.yellow_piece);

        String winType = checkWin(row, bestMove, 2);
        if (!winType.equals("none")) {
            statusText.setText("AI Won " + winType + "!");
            gameOver = true;
            return;
        }

        playerTurn = true;
        statusText.setText("Your Turn!");
    }

    private int getBestMove() {
        for (int col = 0; col < COLS; col++) {
            int row = getAvailableRow(col);
            if (row != -1) {
                board[row][col] = 2;
                if (!checkWin(row, col, 2).equals("none")) {
                    board[row][col] = 0;
                    return col;
                }
                board[row][col] = 0;
            }
        }
        return getRandomMove();
    }

    private int getRandomMove() {
        int col;
        do {
            col = random.nextInt(COLS);
        } while (!isValidMove(col));
        return col;
    }

    private boolean isValidMove(int col) {
        return board[0][col] == 0;
    }

    private int getAvailableRow(int col) {
        for (int row = ROWS - 1; row >= 0; row--) {
            if (board[row][col] == 0) return row;
        }
        return -1;
    }

    private String checkWin(int row, int col, int player) {
        if (checkDirection(row, col, 0, 1, player)) return "Horizontally";
        if (checkDirection(row, col, 1, 0, player)) return "Vertically";
        if (checkDirection(row, col, 1, 1, player)) return "Diagonally (↘)";
        if (checkDirection(row, col, 1, -1, player)) return "Diagonally (↙)";
        return "none";
    }

    private boolean checkDirection(int row, int col, int rowDir, int colDir, int player) {
        int count = 1;
        count += countConsecutive(row, col, rowDir, colDir, player);
        count += countConsecutive(row, col, -rowDir, -colDir, player);
        return count >= 4;
    }

    private int countConsecutive(int row, int col, int rowDir, int colDir, int player) {
        int count = 0;
        for (int i = 1; i < 4; i++) {
            int newRow = row + i * rowDir;
            int newCol = col + i * colDir;
            if (newRow >= 0 && newRow < ROWS && newCol >= 0 && newCol < COLS && board[newRow][newCol] == player) {
                count++;
            } else {
                break;
            }
        }
        return count;
    }

    private void resetGame() {
        initializeBoard();
    }
}
